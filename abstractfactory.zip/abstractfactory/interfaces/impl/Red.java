package com.kunlun.chris.abstractfactory.interfaces.impl;

import com.kunlun.chris.abstractfactory.interfaces.Color;

public class Red implements Color {

	@Override
	public void fill() {
		System.out.println("This is red.");
	}

}

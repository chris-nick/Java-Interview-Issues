package com.kunlun.chris.abstractfactory.interfaces;

public interface Shape {

	void draw();
}

package com.kunlun.chris.abstractfactory.interfaces;

public interface Color {

	void fill();
}

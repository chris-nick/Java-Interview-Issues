package com.kunlun.chris.abstractfactory.factory;

import com.kunlun.chris.abstractfactory.interfaces.Color;
import com.kunlun.chris.abstractfactory.interfaces.Shape;

public abstract class AbstractFactory {

	public abstract Shape getShape(String shape);

	public abstract Color getColor(String color);
}

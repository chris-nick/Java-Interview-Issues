package com.kunlun.chris.abstractfactory.factory;

import com.kunlun.chris.abstractfactory.interfaces.Color;
import com.kunlun.chris.abstractfactory.interfaces.Shape;
import com.kunlun.chris.abstractfactory.interfaces.impl.Blue;
import com.kunlun.chris.abstractfactory.interfaces.impl.Red;
import com.kunlun.chris.abstractfactory.interfaces.impl.White;

public class ColorFactory extends AbstractFactory {

	@Override
	public Shape getShape(String shape) {
		return null;
	}

	@Override
	public Color getColor(String color) {
		if (color == null) {
			return null;
		}
		if (color.equalsIgnoreCase("red")) {
			return new Red();
		}
		if (color.equalsIgnoreCase("white")) {
			return new White();
		}
		if (color.equalsIgnoreCase("blue")) {
			return new Blue();
		}
		return null;
	}

}

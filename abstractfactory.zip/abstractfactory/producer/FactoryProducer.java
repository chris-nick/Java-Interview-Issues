package com.kunlun.chris.abstractfactory.producer;

import com.kunlun.chris.abstractfactory.factory.AbstractFactory;
import com.kunlun.chris.abstractfactory.factory.ColorFactory;
import com.kunlun.chris.abstractfactory.factory.ShapeFactory;

public class FactoryProducer {

	public static AbstractFactory getFactory(String type) {

		if (type == null) {
			return null;
		}
		if (type.equalsIgnoreCase("shape")) {
			return new ShapeFactory();
		}
		if (type.equalsIgnoreCase("color")) {
			return new ColorFactory();
		}
		return null;
	}
}

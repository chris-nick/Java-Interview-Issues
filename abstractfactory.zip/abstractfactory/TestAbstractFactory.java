package com.kunlun.chris.abstractfactory;

import com.kunlun.chris.abstractfactory.factory.AbstractFactory;
import com.kunlun.chris.abstractfactory.interfaces.Color;
import com.kunlun.chris.abstractfactory.interfaces.Shape;
import com.kunlun.chris.abstractfactory.producer.FactoryProducer;

public class TestAbstractFactory {

	public static void main(String[] args) {

		AbstractFactory colorFactory = FactoryProducer.getFactory("color");
		Color color = colorFactory.getColor("red");
		color.fill();

		AbstractFactory shapeFactory = FactoryProducer.getFactory("shape");
		Shape shape = shapeFactory.getShape("circle");
		shape.draw();

	}
}
